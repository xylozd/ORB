from django.db import models

class SignalEvent(models.Model):
    BUY = "BUY"
    SELL = "SELL"
    SIGNAL_CHOICES = [(BUY, "BUY"), (SELL, "SELL")]

    symbol = models.CharField(max_length=32, db_index=True)
    signal = models.CharField(max_length=4, choices=SIGNAL_CHOICES, db_index=True)
    price = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    range_high = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    range_low = models.DecimalField(max_digits=14, decimal_places=4, null=True, blank=True)
    range_pct = models.DecimalField(max_digits=8, decimal_places=4, null=True, blank=True)
    occurred_at = models.DateTimeField(db_index=True)
    source = models.CharField(max_length=32, default="scanner")
    note = models.CharField(max_length=240, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-occurred_at"]
        indexes = [models.Index(fields=["symbol", "-occurred_at"])]

    def __str__(self):
        return f"{self.symbol} {self.signal} @ {self.occurred_at:%Y-%m-%d %H:%M:%S}"
