(() => {
  const $ = (id) => document.getElementById(id);
  let stocks = [];
  const fmt = (value, digits = 2) => {
    if (value === null || value === undefined || value === "") return "—";
    const n = Number(value);
    return Number.isFinite(n) ? n.toLocaleString("en-IN", {minimumFractionDigits: digits, maximumFractionDigits: digits}) : "—";
  };
  const safe = (value) => String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));
  const shortTime = (value) => {
    if (!value) return "—";
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? safe(value) : d.toLocaleTimeString("en-IN", {hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false,timeZone:"Asia/Kolkata"});
  };
  const signalPill = (signal) => {
    const s = (signal || "—").toUpperCase();
    const cls = s === "BUY" ? "signal-buy" : s === "SELL" ? "signal-sell" : "signal-none";
    return `<span class="signal-pill ${cls}">${safe(s)}</span>`;
  };
  const statusPill = (status) => {
    const s = (status || "UNKNOWN").toUpperCase();
    const cls = s === "ELIGIBLE" ? "status-eligible" : s === "REJECTED" ? "status-rejected" : "status-error";
    return `<span class="status-pill ${cls}">${safe(s)}</span>`;
  };
  function renderStocks() {
    const q = $("search-input").value.trim().toUpperCase();
    const status = $("status-filter").value;
    const signal = $("signal-filter").value;
    const visible = stocks.filter(s => {
      const matchesText = !q || s.symbol.includes(q) || (s.company || "").toUpperCase().includes(q);
      const matchesStatus = status === "ALL" || s.status === status;
      const matchesSignal = signal === "ALL" || (signal === "NONE" ? !["BUY","SELL"].includes(s.signal) : s.signal === signal);
      return matchesText && matchesStatus && matchesSignal;
    });
    $("row-count").textContent = `${visible.length} of ${stocks.length} stocks`;
    $("stock-rows").innerHTML = visible.length ? visible.map(s => {
      const pct = s.range_pct === null ? null : Number(s.range_pct);
      return `<tr>
        <td><span class="symbol-cell">${safe(s.symbol)}</span></td>
        <td class="number-cell">${fmt(s.range_high)}</td>
        <td class="number-cell">${fmt(s.range_low)}</td>
        <td class="number-cell ${pct === null ? "muted-cell" : pct <= 1 ? "range-good" : "range-bad"}">${pct === null ? "—" : fmt(pct,4)+"%"}</td>
        <td class="number-cell">${s.current_price == null ? "—" : "₹"+fmt(s.current_price)}</td>
        <td>${signalPill(s.signal)}</td>
        <td class="number-cell">${shortTime(s.signal_time)}</td>
        <td>${statusPill(s.status)}</td>
      </tr>`;
    }).join("") : `<tr><td colspan="8" class="empty-cell">No stocks match these filters.</td></tr>`;
  }
  async function refreshDashboard() {
    try {
      const response = await fetch("/api/dashboard/", {headers: {"Accept":"application/json"}, cache:"no-store"});
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      stocks = Array.isArray(data.stocks) ? data.stocks : [];
      $("total-count").textContent = data.total ?? stocks.length;
      $("eligible-count").textContent = data.eligible ?? 0;
      $("signal-count").textContent = data.signals ?? 0;
      const connected = String(data.connection || "").toLowerCase() === "connected";
      $("connection-label").textContent = connected ? "Feed connected" : "Feed not connected";
      $("last-update").textContent = data.last_update ? shortTime(data.last_update) : "Not available";
      $("data-source").textContent = data.last_update ? "Last market tick (IST)" : "Waiting for live_state.json";
      renderStocks();
    } catch (err) {
      $("connection-label").textContent = "Dashboard API error";
      $("data-source").textContent = "Could not load scanner data";
    }
  }
  async function refreshHistory() {
    try {
      const selected = $("history-signal").value;
      const params = new URLSearchParams({limit:"200"});
      if (selected !== "ALL") params.set("signal", selected);
      const response = await fetch(`/api/history/?${params}`, {headers: {"Accept":"application/json"}, cache:"no-store"});
      if (!response.ok) throw new Error("History request failed");
      const data = await response.json();
      const events = data.events || [];
      $("history-count").textContent = `${events.length} events`;
      $("history-rows").innerHTML = events.length ? events.map(e => `<tr>
        <td class="number-cell">${shortTime(e.occurred_at)}</td><td><span class="symbol-cell">${safe(e.symbol)}</span></td>
        <td>${signalPill(e.signal)}</td><td class="number-cell">${e.price == null ? "—" : "₹"+fmt(e.price)}</td>
        <td class="number-cell">${fmt(e.range_high)}</td><td class="number-cell">${fmt(e.range_low)}</td>
        <td class="number-cell">${e.range_pct == null ? "—" : fmt(e.range_pct,4)+"%"}</td></tr>`).join("") :
        `<tr><td colspan="7" class="empty-cell">No historical signal events recorded yet. Signal persistence will populate this table when the feed worker is connected.</td></tr>`;
    } catch (_) {
      $("history-rows").innerHTML = `<tr><td colspan="7" class="empty-cell">Could not load signal history.</td></tr>`;
    }
  }
  ["search-input","status-filter","signal-filter"].forEach(id => $(id).addEventListener(id === "search-input" ? "input" : "change", renderStocks));
  $("refresh-btn").addEventListener("click", refreshDashboard);
  $("history-refresh").addEventListener("click", refreshHistory);
  $("history-signal").addEventListener("change", refreshHistory);
  refreshDashboard();
  refreshHistory();
  window.setInterval(refreshDashboard, 5000);
  window.setInterval(refreshHistory, 30000);
})();
