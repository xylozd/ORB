import csv
import json
from datetime import datetime
from pathlib import Path

from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.utils.http import url_has_allowed_host_and_scheme
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from .models import SignalEvent


def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    error = ""
    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "")
        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_active:
            login(request, user)
            next_url = request.GET.get("next", "")
            if next_url and url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
                return redirect(next_url)
            return redirect("dashboard")
        error = "Invalid username or password."
    return render(request, "dashboard/login.html", {"error": error})


@login_required
@require_POST
def logout_view(request):
    logout(request)
    return redirect("login")


def _read_csv(path):
    try:
        with path.open("r", newline="", encoding="utf-8-sig") as handle:
            return list(csv.DictReader(handle))
    except (OSError, csv.Error, UnicodeError):
        return []


def _read_live_state():
    path = settings.ORB_PROJECT_DIR / "live_state.json"
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            return data
    except (OSError, json.JSONDecodeError):
        pass
    return {"connection": "not_connected", "last_update": None, "prices": {}, "signals": {}}


def _dashboard_payload():
    rows = _read_csv(settings.ORB_PROJECT_DIR / "opening_ranges.csv")
    live = _read_live_state()
    prices = live.get("prices") if isinstance(live.get("prices"), dict) else {}
    signals = live.get("signals") if isinstance(live.get("signals"), dict) else {}
    stocks = []

    for row in rows:
        symbol = str(row.get("symbol", "")).strip().upper()
        if not symbol:
            continue
        price_data = prices.get(symbol, {})
        signal_data = signals.get(symbol, {})
        if not isinstance(price_data, dict):
            price_data = {}
        if not isinstance(signal_data, dict):
            signal_data = {}
        stocks.append({
            "symbol": symbol,
            "company": row.get("company", ""),
            "range_high": row.get("range_high") or None,
            "range_low": row.get("range_low") or None,
            "range_pct": row.get("range_pct") or None,
            "status": row.get("status", "UNKNOWN"),
            "current_price": price_data.get("price"),
            "price_updated_at": price_data.get("updated_at"),
            "signal": signal_data.get("signal", "—"),
            "signal_time": signal_data.get("signal_time"),
            "reason": row.get("reason", ""),
        })

    stocks.sort(key=lambda item: item["symbol"])
    eligible = sum(s["status"] == "ELIGIBLE" for s in stocks)
    live_signal_count = sum(s["signal"] in ("BUY", "SELL") for s in stocks)
    return {
        "as_of": timezone.localtime().isoformat(),
        "connection": live.get("connection", "not_connected"),
        "last_update": live.get("last_update"),
        "total": len(stocks),
        "eligible": eligible,
        "signals": live_signal_count,
        "stocks": stocks,
    }


@login_required
def dashboard(request):
    return render(request, "dashboard/index.html")


@login_required
@require_GET
def dashboard_api(request):
    return JsonResponse(_dashboard_payload())


@login_required
@require_GET
def history_api(request):
    qs = SignalEvent.objects.all()
    symbol = request.GET.get("symbol", "").strip().upper()
    signal = request.GET.get("signal", "").strip().upper()
    if symbol:
        qs = qs.filter(symbol__icontains=symbol)
    if signal in {"BUY", "SELL"}:
        qs = qs.filter(signal=signal)

    try:
        limit = min(max(int(request.GET.get("limit", "100")), 1), 500)
    except ValueError:
        limit = 100

    events = [{
        "symbol": e.symbol,
        "signal": e.signal,
        "price": str(e.price) if e.price is not None else None,
        "range_high": str(e.range_high) if e.range_high is not None else None,
        "range_low": str(e.range_low) if e.range_low is not None else None,
        "range_pct": str(e.range_pct) if e.range_pct is not None else None,
        "occurred_at": timezone.localtime(e.occurred_at).isoformat(),
        "source": e.source,
        "note": e.note,
    } for e in qs[:limit]]
    return JsonResponse({"events": events, "count": len(events)})
