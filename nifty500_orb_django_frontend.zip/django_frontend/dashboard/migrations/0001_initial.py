from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="SignalEvent",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("symbol", models.CharField(db_index=True, max_length=32)),
                ("signal", models.CharField(choices=[("BUY", "BUY"), ("SELL", "SELL")], db_index=True, max_length=4)),
                ("price", models.DecimalField(blank=True, decimal_places=4, max_digits=14, null=True)),
                ("range_high", models.DecimalField(blank=True, decimal_places=4, max_digits=14, null=True)),
                ("range_low", models.DecimalField(blank=True, decimal_places=4, max_digits=14, null=True)),
                ("range_pct", models.DecimalField(blank=True, decimal_places=4, max_digits=8, null=True)),
                ("occurred_at", models.DateTimeField(db_index=True)),
                ("source", models.CharField(default="scanner", max_length=32)),
                ("note", models.CharField(blank=True, max_length=240)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"ordering": ["-occurred_at"]},
        ),
        migrations.AddIndex(
            model_name="signalevent",
            index=models.Index(fields=["symbol", "-occurred_at"], name="dashboard_s_symbol__3a1c3a_idx"),
        ),
    ]
