from django.contrib import admin
from .models import SignalEvent

@admin.register(SignalEvent)
class SignalEventAdmin(admin.ModelAdmin):
    list_display = ("occurred_at", "symbol", "signal", "price", "range_pct", "source")
    list_filter = ("signal", "source", "occurred_at")
    search_fields = ("symbol", "note")
    date_hierarchy = "occurred_at"
    ordering = ("-occurred_at",)
    readonly_fields = ("created_at",)
