# Nifty 500 ORB Dashboard (Django)

A login-protected Django dashboard scaffold for the existing `~/nifty500-orb` scanner.
It does not place orders. It reads the scanner's `opening_ranges.csv` and optionally
reads `live_state.json` for live prices/signals produced by a separate market-feed worker.

## 1. Install on the Oracle VM

Copy this folder to `~/nifty500-orb/django_frontend`, then:

```bash
cd ~/nifty500-orb/django_frontend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

Set a long random `DJANGO_SECRET_KEY`, your intended `DJANGO_ALLOWED_HOSTS` (domain/IP),
and `DJANGO_CSRF_TRUSTED_ORIGINS` (for example `https://your-domain.example`).
Do not put Angel One credentials in this Django `.env`; the scanner's existing `.env`
should remain separate.

Create the database and a dashboard login:

```bash
python manage.py migrate
python manage.py createsuperuser
python manage.py check --deploy
python manage.py runserver 127.0.0.1:8000
```

Open a local SSH tunnel to test, or put Nginx + HTTPS in front of Gunicorn for public access.
Do not expose Django's development server directly to the Internet.

## 2. Connect to existing scanner files

By default, `ORB_PROJECT_DIR` points one level up from `django_frontend`, i.e.
`~/nifty500-orb`. The dashboard reads `opening_ranges.csv` from that directory.

Optional `live_state.json` format (written atomically by a future WebSocket feed worker):

```json
{
  "connection": "connected",
  "last_update": "2026-10-13T10:30:00+05:30",
  "prices": {
    "ACC": {"price": 1890.25, "updated_at": "2026-10-13T10:30:00+05:30"}
  },
  "signals": {
    "ACC": {"signal": "BUY", "signal_time": "2026-10-13T10:20:15+05:30"}
  }
}
```

Until a feed worker writes this file, the UI correctly shows that live feed data is not connected;
it will not fabricate prices or signals. Historical signal events can be recorded using the Django
admin or the `SignalEvent` model.

## 3. Public access/security checklist

- Use HTTPS and Nginx/Gunicorn; do not expose `runserver`.
- Use a strong secret key and correct host/CSRF allowlists.
- Keep `DEBUG=False`.
- Use a non-root Linux service account if possible.
- Keep Angel One API key, PIN, TOTP secret and session files out of Django/static files.
- Restrict `/admin/` and dashboard access with strong passwords; consider SSH/VPN or IP restrictions.
- Configure firewall to expose only 80/443, not port 8000.
