from django.contrib import admin
from django.urls import path
from dashboard import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/login/", views.login_view, name="login"),
    path("accounts/logout/", views.logout_view, name="logout"),
    path("", views.dashboard, name="dashboard"),
    path("api/dashboard/", views.dashboard_api, name="dashboard_api"),
    path("api/history/", views.history_api, name="history_api"),
]
